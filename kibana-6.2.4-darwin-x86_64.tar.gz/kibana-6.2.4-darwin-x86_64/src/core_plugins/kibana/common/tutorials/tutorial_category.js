'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const TUTORIAL_CATEGORY = exports.TUTORIAL_CATEGORY = {
  LOGGING: 'logging',
  SECURITY: 'security',
  METRICS: 'metrics',
  OTHER: 'other'
};
