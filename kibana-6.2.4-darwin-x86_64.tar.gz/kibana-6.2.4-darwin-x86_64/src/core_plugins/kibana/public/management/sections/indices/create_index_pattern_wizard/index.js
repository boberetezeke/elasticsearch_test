import './create_index_pattern_wizard';
