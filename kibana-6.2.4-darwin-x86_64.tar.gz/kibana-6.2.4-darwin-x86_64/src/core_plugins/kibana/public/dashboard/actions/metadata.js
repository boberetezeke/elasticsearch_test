import { createAction } from 'redux-actions';

export const updateDescription = createAction('UPDATE_DESCRIPTION');
export const updateTitle = createAction('UPDATE_TITLE');
