'use strict';

require('jquery');
require('angular');
require('angular-sanitize');
require('ui-select/dist/select');
require('ui-select/dist/select.css');

require('ui/modules').get('kibana', ['ui.select', 'ngSanitize']);
